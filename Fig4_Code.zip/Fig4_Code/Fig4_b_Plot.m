clear all
close all
clc
font_size=20; line_width=2; Markersize=7;

NN=20; 

AA=[15 10 5]

f=175*10^3;  W=2*pi*f;

C0=10*10^(-12); C1=220*10^(-12);   C2=30*10^(-12); C3=200*10^(-12);   
t1L=-1i*W*C1;    dt=-1i*W*C2; 

L1=470*10^(-6);  Cr=1.5*10^(-9);   


for pp=1:3
    if(pp==1)
        px=AA(1);  R=28000; 
    elseif(pp==2)
        px=AA(2);  R=22000;
    elseif(pp==3)
        px=AA(3);  R=16000;
    end
    
    dd=-1i*(1/(W*L1)-W*(C1+C0+Cr))+1/R;
    
    %%%%%%%%%%%%%%%%%%   HH    %%%%%%%%%%%%%%%%%%%
    HH=0;  
    for k1=1:NN-1
        HH(k1,k1+1)=t1L;
    end
    for k1=1:NN
        HH(k1,k1)=dd;
    end
   
    HH(NN,px)=dt;
    
    HH=1i*HH;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    [Vm1,Emm1] = eig(HH);
    Em1=diag(Emm1);
    [E1,V1]=RankEVabs(Em1,Vm1,NN);
    
    
    Vabs=abs(V1);
    
    for k1=1:NN-1
        Xib(k1)=Vabs(k1,NN)/Vabs(k1+1,NN);
    end
   

    Vpabs(:,:,pp)=Vabs; 
    Xip(pp,1)=NN-px+1;
    Xip(pp,2)=1/log(Xib(1));
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%       Experiment      %%%%%%%%%%%%%%%%

G1=load('L=6.txt');

G2=load('L=11.txt');

G3=load('L=16.txt');   

%%%%%%%%%%%%%%%%%%%%%%%%%%

for k1=1:NN-1
     S1(k1,1)=G1(k1)/G1(k1+1);
     S2(k1,1)=G2(k1)/G2(k1+1);
     S3(k1,1)=G3(k1)/G3(k1+1); 
end



Xip(1,3)=1/log(mean(S1));
Xip(2,3)=1/log(mean(S2));  
Xip(3,3)=1/log(mean(S3));  


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    Plot    %%%%%%%%%%%%%%%%%%%%5
figure(1)

subplot(2,2,1)
plot(1:NN,Vpabs(:,NN,1)*G1(NN)/Vpabs(NN,NN,1),'k.-',1:NN,Vpabs(:,NN,2)*G2(NN)/Vpabs(NN,NN,2),'k.-',1:NN,Vpabs(:,NN,3)*G3(NN)/Vpabs(NN,NN,3),'k.-','linewidth',line_width,'Markersize',5);
hold on;
plot(1:NN,G1,'dr','linewidth',line_width,'Markersize',12);
hold on;
plot(1:NN,G2,'b<','linewidth',line_width,'Markersize',12);
hold on;
plot(1:NN,G3,'g+','linewidth',line_width,'Markersize',15);
hold on;
xlabel('n');
ylabel('|V_n|(mV)');
set(gca,'FontName','Times New Roman','FontSize',font_size,'fontweight','bold')
xlim([1 NN])

subplot(2,2,2)
plot(Xip(:,1),Xip(:,2),'k.-','linewidth',line_width,'Markersize',5);
hold on;
plot(Xip(1,1),Xip(1,3),'dr','linewidth',line_width,'Markersize',12);
hold on;
plot(Xip(2,1),Xip(2,3),'b>','linewidth',line_width,'Markersize',12);
hold on;
plot(Xip(3,1),Xip(3,3),'g+','linewidth',line_width,'Markersize',15);
hold on;
xlabel('l');
ylabel('\xi');
set(gca,'FontName','Times New Roman','FontSize',font_size,'fontweight','bold')
xlim([1 NN])




