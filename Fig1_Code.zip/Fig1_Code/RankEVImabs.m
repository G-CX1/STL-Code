function [Ein,Vin]=RankEVImabs(Egin,Vcin,Ncin) % ������ʵ��Ϊ��һ˳���鲿Ϊ�ڶ�˳��
deltain=0.000000001;
for Qin1=1:1:Ncin
    for Qin2=Qin1+1:1:Ncin
        if (abs(imag(Egin(Qin1)))>(abs(imag(Egin(Qin2)))+deltain)) 
            midEin=Egin(Qin2);  midVin=Vcin(:,Qin2);
            Egin(Qin2)=Egin(Qin1); Vcin(:,Qin2)=Vcin(:,Qin1);
            Egin(Qin1)=midEin; Vcin(:,Qin1)=midVin;
        elseif ((abs(imag(Egin(Qin1)))>=(abs(imag(Egin(Qin2)))-deltain)))&&((abs(imag(Egin(Qin1)))<=(abs(imag(Egin(Qin2)))+deltain)))
            if (abs(real(Egin(Qin1)))>(abs(real(Egin(Qin2)))+deltain)) 
                midEin=Egin(Qin2);  midVin=Vcin(:,Qin2);
                Egin(Qin2)=Egin(Qin1); Vcin(:,Qin2)=Vcin(:,Qin1);
                Egin(Qin1)=midEin; Vcin(:,Qin1)=midVin;
            end
        end
     end
end
Ein=Egin;
Vin=Vcin;