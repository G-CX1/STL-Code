clear all
close all
clc
font_size=38; line_width=2; Markersize=7;


Ncell=20;  


%****************    Fig1b,d  H1   *******************%
t1L=1;  t2L=t1L;
t1R=0;  t2R=0;

AA=[36 31 21 11 36 31 21 11]
LL=2*Ncell+1-AA;   % L=2*Ncell+1-pp=5,10,20,30


for pp=1:8
    
if(pp==1)
    dt=0.1;  MM=1;  px=AA(1);   
elseif(pp==2)
    dt=0.1;  MM=1;  px=AA(2);   
elseif(pp==3)
    dt=0.1;  MM=1;  px=AA(3);   
elseif(pp==4)
    dt=0.1;  MM=1;  px=AA(4);  
elseif(pp==5)
    dt=10;  MM=2*Ncell;  px=AA(5);   
elseif(pp==6)
    dt=10;  MM=2*Ncell;  px=AA(6);  
elseif(pp==7)
    dt=10;  MM=2*Ncell;  px=AA(7);   
elseif(pp==8)
    dt=10;  MM=2*Ncell;  px=AA(8); 
end

H1=sparse(sparse(kron(sparse(diag(ones(1,Ncell))),[0,t1L;t1R,0]))+sparse(kron(sparse(diag(ones(1,Ncell-1),1)),[0,0;t2L,0]))+sparse(kron(sparse(diag(ones(1,Ncell-1),-1)),[0,t2R;0,0])));
H1(2*Ncell,px)=dt;

[Vm1,Emm1] = eig(full(H1));
Em1=diag(Emm1);   
[E1,V1]=RankEVImabs(Em1,Vm1,2*Ncell);


Vb1=conj(V1).*V1;

for k1=1:2*Ncell
E1s(k1,pp)=E1(k1);
end

V1m=zeros(2*Ncell-px+1);

for k1=1:2*Ncell
    for k2=1:2*Ncell-px+1
         V1m(k1,k2)=Vb1(k1,px-1+k2);
    end
end

V1mm=mean(V1m,2);

for k1=1:2*Ncell
V1pm(k1,pp)=V1mm(k1);
end

for k1=1:2*Ncell
V1scale(k1,pp)=V1mm(k1)/V1mm(MM);
end

for j1=1:2*Ncell
    NNN(j1,pp)=(j1-MM)/(2*Ncell+1-px);
end
end
ReE=real(E1s);ImE=imag(E1s);

r1=0.1^(1/LL(1));  r2=0.1^(1/LL(2));  r3=0.1^(1/LL(3));  r4=0.1^(1/LL(4));
r5=10^(1/LL(5));   r6=10^(1/LL(6));   r7=10^(1/LL(7));   r8=10^(1/LL(8));
r9=1;
qw=0;
for kk=0:0.01:2*pi
    qw=qw+1;
    R1(qw)=(r1*exp(1i*kk)); R2(qw)=(r2*exp(1i*kk)); R3(qw)=(r3*exp(1i*kk)); R4(qw)=(r4*exp(1i*kk));   
    R5(qw)=(r5*exp(1i*kk)); R6(qw)=(r6*exp(1i*kk)); R7(qw)=(r7*exp(1i*kk)); R8(qw)=(r8*exp(1i*kk)); 
    R9(qw)=exp(1i*kk);
end

R(1)=r1; R(2)=r2; R(3)=r3; R(4)=r4; R(5)=r5; R(6)=r6; 
R(7)=r7; R(8)=r8; R(9)=r9; 


%****************    Fig1c  H2   *******************%
DDT=[0.001 0.05 0.25 1 4 20 1000];
for qq=1:7
    dtt=DDT(qq);
    
H2=sparse(sparse(kron(sparse(diag(ones(1,Ncell))),[0,t1L;t1R,0]))+sparse(kron(sparse(diag(ones(1,Ncell-1),1)),[0,0;t2L,0]))+sparse(kron(sparse(diag(ones(1,Ncell-1),-1)),[0,t2R;0,0])));
H2(2*Ncell,21)=dtt;

[Vm2,Emm2] = eig(full(H2));
Em2=diag(Emm2);   
[E2,V2]=RankEVImabs(Em2,Vm2,2*Ncell);


Vb2=conj(V2).*V2;

Vcc(:,qq)=Vb2(:,2*Ncell);

 
end



%****************    Fig1e  H3   *******************%

AB=[5 10 15 20];

L3=5;

pa=0;
for Ncell3=AB
    pa=pa+1;
    ddd(pa)=Ncell3;
    px3=2*Ncell3-L3+1;
    MM3=1;

H3=sparse(sparse(kron(sparse(diag(ones(1,Ncell3))),[0,t1L;t1R,0]))+sparse(kron(sparse(diag(ones(1,Ncell3-1),1)),[0,0;t2L,0]))+sparse(kron(sparse(diag(ones(1,Ncell3-1),-1)),[0,t2R;0,0])));
H3(2*Ncell3,px3)=0.1;

H33=full(H3);
[Vm3,Emm3] = eig(full(H3));
Em3=diag(Emm3);   
[E3,V3]=RankEVImabs(Em3,Vm3,2*Ncell3);

Vb3=conj(V3).*V3;

Vbb3=zeros(2*Ncell3);
for j1=1:2*Ncell3
    Vbb3(:,j1)=Vb3(:,j1)/Vb3(MM3,j1);
end

for k1=1:2*Ncell3
VV3(k1,pa)=Vbb3(k1,2*Ncell3);
end

 for j1=1:2*Ncell3
     NNNe(j1,pa)=(j1-MM3)/(2*Ncell3);
 end

end





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   Write  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

dlmwrite('Er.txt', ReE, 'delimiter', ' ', 'precision', '%d');
dlmwrite('Ei.txt', ImE, 'delimiter', ' ', 'precision', '%d');
dlmwrite('R.txt', R, 'delimiter', ' ', 'precision', '%d');
dlmwrite('Vc.txt', Vcc, 'delimiter', ' ', 'precision', '%d');
dlmwrite('N1.txt', NNN, 'delimiter', ' ', 'precision', '%d');
dlmwrite('V.txt', V1scale, 'delimiter', ' ', 'precision', '%d');
dlmwrite('Ns.txt', NNNe, 'delimiter', ' ', 'precision', '%d');
dlmwrite('Vs.txt', VV3, 'delimiter', ' ', 'precision', '%d');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
font_size=28;


figure(1); 
subplot(2,3,1)
plot(real(R9(:)),imag(R9(:)),'k.','linewidth',line_width,'Markersize',4);
hold on;
plot(real(R1(:)),imag(R1(:)),'r.','linewidth',line_width,'Markersize',4);
hold on;
plot(real(R2(:)),imag(R2(:)),'b.','linewidth',line_width,'Markersize',4);
hold on;
plot(real(R3(:)),imag(R3(:)),'m.','linewidth',line_width,'Markersize',4);
hold on;
plot(real(R5(:)),imag(R5(:)),'r.','linewidth',line_width,'Markersize',4);
hold on;
plot(real(R6(:)),imag(R6(:)),'b.','linewidth',line_width,'Markersize',4);
hold on;
plot(real(R7(:)),imag(R7(:)),'m.','linewidth',line_width,'Markersize',4);
hold on;
plot(real(E1s(1:AA(1)-1,1)),imag(E1s(1:AA(1)-1,1)),'ro',real(E1s(AA(1):2*Ncell,1)),imag(E1s(AA(1):2*Ncell,1)),'ro','linewidth',line_width,'Markersize',9);
hold on;
plot(real(E1s(1:AA(2)-1,2)),imag(E1s(1:AA(2)-1,2)),'bo',real(E1s(AA(2):2*Ncell,2)),imag(E1s(AA(2):2*Ncell,2)),'bo','linewidth',line_width,'Markersize',7);
hold on;
plot(real(E1s(1:AA(3)-1,3)),imag(E1s(1:AA(3)-1,3)),'mo',real(E1s(AA(3):2*Ncell,3)),imag(E1s(AA(3):2*Ncell,3)),'mo','linewidth',line_width,'Markersize',8);
hold on;
plot(real(E1s(1:AA(5)-1,5)),imag(E1s(1:AA(5)-1,5)),'ro',real(E1s(AA(5):2*Ncell,5)),imag(E1s(AA(5):2*Ncell,5)),'ro','linewidth',line_width,'Markersize',9);
hold on;
plot(real(E1s(1:AA(6)-1,6)),imag(E1s(1:AA(6)-1,6)),'bo',real(E1s(AA(6):2*Ncell,6)),imag(E1s(AA(6):2*Ncell,6)),'bo','linewidth',line_width,'Markersize',7);
hold on;
plot(real(E1s(1:AA(7)-1,7)),imag(E1s(1:AA(7)-1,7)),'mo',real(E1s(AA(7):2*Ncell,7)),imag(E1s(AA(7):2*Ncell,7)),'mo','linewidth',line_width,'Markersize',8);
hold on;
xlabel('Re(E)');
ylabel('Im(E)');
set(gca,'FontName','Times New Roman','FontSize',font_size,'fontweight','bold')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
subplot(2,3,2)
plot(1:2*Ncell,Vcc(:,1),'r.-','linewidth',line_width,'Markersize',4);
hold on;
plot(1:2*Ncell,Vcc(:,2),'b.-','linewidth',line_width,'Markersize',4);
hold on;
plot(1:2*Ncell,Vcc(:,3),'g.-','linewidth',line_width,'Markersize',4);
hold on;
plot(1:2*Ncell,Vcc(:,4),'k.-','linewidth',line_width,'Markersize',4);
hold on;
plot(1:2*Ncell,Vcc(:,5),'g.-','linewidth',line_width,'Markersize',4);
hold on;
plot(1:2*Ncell,Vcc(:,6),'b.-','linewidth',line_width,'Markersize',4);
hold on;
plot(1:2*Ncell,Vcc(:,7),'r.-','linewidth',line_width,'Markersize',4);
hold on;
set(gca,'FontName','Times New Roman','FontSize',font_size,'fontweight','bold')
ylim([0 0.6])



% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
subplot(2,3,4)
plot(NNN(1:2*Ncell,1),V1scale(1:2*Ncell,1),'ro-','linewidth',line_width,'Markersize',14);
hold on;
plot(NNN(1:2*Ncell,2),V1scale(1:2*Ncell,2),'bo-','linewidth',line_width,'Markersize',10);
hold on;
plot(NNN(1:2*Ncell,3),V1scale(1:2*Ncell,3),'mo-','linewidth',line_width,'Markersize',7);
hold on;
plot(NNN(1:2*Ncell,4),V1scale(1:2*Ncell,4),'go-','linewidth',line_width,'Markersize',4);
hold on;
xlabel('(n-n_0)/l');
ylabel('|\psi|^2');
set(gca,'FontName','Times New Roman','FontSize',font_size,'fontweight','bold')
xlim([0 3])

subplot(2,3,5)
plot(NNN(1:2*Ncell,5),V1scale(1:2*Ncell,5),'ro-','linewidth',line_width,'Markersize',14);
hold on;
plot(NNN(1:2*Ncell,6),V1scale(1:2*Ncell,6),'bo-','linewidth',line_width,'Markersize',10);
hold on;
plot(NNN(1:2*Ncell,7),V1scale(1:2*Ncell,7),'mo-','linewidth',line_width,'Markersize',7);
hold on;
plot(NNN(1:2*Ncell,8),V1scale(1:2*Ncell,8),'go-','linewidth',line_width,'Markersize',4);
hold on;
xlabel('(n-n_0)/l');
ylabel('|\psi|^2');
set(gca,'FontName','Times New Roman','FontSize',font_size,'fontweight','bold')
xlim([-3 0])


subplot(2,3,6)
plot(NNNe(1:2*AB(1),1),VV3(1:2*AB(1),1),'mo-','linewidth',line_width,'Markersize',12);
hold on;
plot(NNNe(1:2*AB(2),2),VV3(1:2*AB(2),2),'go-','linewidth',line_width,'Markersize',8);
hold on;
plot(NNNe(1:2*AB(3),3),VV3(1:2*AB(3),3),'bo-','linewidth',line_width,'Markersize',6);
hold on;
plot(NNNe(1:2*AB(4),4),VV3(1:2*AB(4),4),'ro-','linewidth',line_width,'Markersize',6);
hold on;

xlabel('(n-n_0)/N');
ylabel('|\psi|^2');
set(gca,'FontName','Times New Roman','FontSize',font_size,'fontweight','bold')
xlim([0 0.6])






